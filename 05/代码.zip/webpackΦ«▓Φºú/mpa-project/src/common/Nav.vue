<template>
  <nav>
    <li><a href="./home.html">首页</a></li>
    <li><a href="./product.html">产品</a></li>
    <li><a href="./about.html">关于</a></li>
  </nav>
</template>
