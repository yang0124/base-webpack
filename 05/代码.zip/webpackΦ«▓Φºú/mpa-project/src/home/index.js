import {Person} from './person'
import './style.css'

const zhangsan = new Person('张三', 20);

document.write(zhangsan.say());