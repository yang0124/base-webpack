export class Person{
  constructor(name, age){
    this.name = name;
    this.age = age;
  }

  say(){
    return `my name is ${this.name}, my age is ${age}`
  }
}

