import './style.css'

document.write('关于我们');