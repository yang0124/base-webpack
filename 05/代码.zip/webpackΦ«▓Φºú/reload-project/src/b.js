console.log('a');
console.log('b');
console.log('c');
console.log('d');