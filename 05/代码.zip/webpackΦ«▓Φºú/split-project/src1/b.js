import React from 'react'
import ReactDOM from 'react-dom'



ReactDOM.render(
  <div>
    <h1>这是app的modal部分</h1>
  </div>,
  document.querySelector('#modal')
)
