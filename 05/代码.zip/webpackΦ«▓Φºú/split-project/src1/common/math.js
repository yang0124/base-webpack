export function add(a, b){
  return a + b;
}

export function reduce(a, b){
  return a - b;
}