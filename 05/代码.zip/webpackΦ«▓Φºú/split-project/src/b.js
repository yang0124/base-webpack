import $ from 'jquery'

import React from 'react'
import(/* webpackChunkName: "b-react" */'react')

import(/* webpackChunkName: "b-lodash" */'lodash')


console.log('这是b模块')