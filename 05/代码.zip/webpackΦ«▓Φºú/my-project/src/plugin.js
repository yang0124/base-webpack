import {message} from './my_module'
import './plugin.scss'
console.log(message);