export const message = 'hello world';


export const print = (...rest)=>{
  console.log(rest);
}