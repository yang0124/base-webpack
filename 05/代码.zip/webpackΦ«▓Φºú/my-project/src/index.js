import {message, print} from './my_module'

document.write(message);


print('千锋教育');



console.log('hello');