import Vue from 'vue'
import App from './App'


Vue.prototype.$eventBus = new Vue();

new Vue({
  render: h=>h(App),
  el: '#app'
});