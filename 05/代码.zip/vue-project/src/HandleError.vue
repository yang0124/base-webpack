<template>
<div>
  <h1>异常错误！请刷新页面</h1>
</div>
</template>

<script>
export default {

}
</script>

<style>

</style>