<template>
<div >
  <template v-if="!isError">
    <Add/>
    <hr/>
    <List/>
  </template>

  <HandleError v-else/>

  <nav>
    <button @click="changeAction(0)">首页</button>
    <button @click="changeAction(1)">设置</button>
  </nav>

  <component :is="pageName"/>
  
</div>
</template>


<script>
import Add from './components/Add'
import List from './components/List'
import HandleError from './HandleError'
import Home from './pages/Home'
import Setting from './pages/Setting'
export default {
  components: {
    Add,
    List,
    HandleError,
    Home,
    Setting
  },
  data(){
    return {
      isError: false,
      activeIndex: 0
    }
  },
  computed: {
    pageName(){
      switch (this.activeIndex) {
        case 0:
          return 'Home'
          break;

        default:
          return 'Setting'
          break;
      }
    }
  },
  methods: {
    changeAction(index){
      this.activeIndex = index;
    }
  },
  errorCaptured(){
    console.log('root捕获发生了错误....');
    this.isError = true;
    //收集错误，发送给服务器
  }
}
</script>