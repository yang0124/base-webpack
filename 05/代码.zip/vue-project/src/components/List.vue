<template>
<ul>
  <Item v-for="(item, index) in dataSource" :key="index"
   :value="item" 
   :index="index"

   @delete="handleDelete(index)"

   :deleteFunc="handleDelete"
  >

    <!-- <img slot="item" src="https://i.52112.com/icon/jpg/256/20200109/71104/3033821.jpg" width="15"/>
    <img slot="delete" src="https://i.52112.com/icon/jpg/256/20190830/56445/2516260.jpg" width="20"/> -->

    <!-- v-slot vue2.6+ -->
    <template  v-slot:item="{width}">
      <img src="https://i.52112.com/icon/jpg/256/20200109/71104/3033821.jpg" :width="width"/>
    </template>

    <template  v-slot:delete>
      <img src="https://i.52112.com/icon/jpg/256/20190830/56445/2516260.jpg" width="20"/>
    </template>


  </Item>

</ul>
</template>

<script>
// import Item from './Item'
export default {
  components: {
    Item: ()=>import('./Item')
  },
  data(){
    return {
      dataSource: []
    }
  },
  created(){
    this.$eventBus.$on('add', (param)=>{
      this.dataSource.push(param);
    });
  },
  methods: {
    handleDelete(index){
      console.log('接收到了删除事件。。。。', index);
      this.dataSource.splice(index, 1);
    }
  },
  errorCaptured(){
    console.log('list捕获发生了错误....');

  }
}
</script>

<style>

</style>