<template>
<li>
  <slot name="item" :width="30"/>
  {{value}}
  
  <button @click="deleteAction">
    <slot name="delete">删除</slot>
  </button>
</li>
</template>

<script>
export default {
  props:{
    value: String,
    index: Number,
    deleteFunc: Function
  },
  methods: {
    deleteAction(){
      console.log('删除。。。。');

      

      // this.$emit('delete', this.index)

      this.deleteFunc(this.index);
    }
  },
  mounted(){
    // document.querySelector('.box').style.backgroundColor = 'red';
    // this.value.map(item=>{
    //   console.log(item);
    // })
  },
  errorCaptured(){
    console.log('item捕获发生了错误....');
  }
}
</script>

<style>
li{
  list-style: none;
}
</style>