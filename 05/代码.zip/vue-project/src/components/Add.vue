<template>
<div>
  <!-- <input type="text" v-model="value"/> -->
  <input type="text" ref="inp"/>
  <button @click="addAction">添加</button>
</div> 
</template>

<script>
export default {
  data(){
    return {
      value: ''
    }
  },

  methods: {
    addAction(){
      // console.log(this.value);
      console.log(this.$refs.inp.value);
      const value = this.$refs.inp.value;
      this.$eventBus.$emit('add', value);
      this.$refs.inp.value = '';
    }
  }
}
</script>

<style>

</style>